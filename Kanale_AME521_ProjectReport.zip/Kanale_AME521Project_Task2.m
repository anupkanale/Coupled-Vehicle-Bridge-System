%-----------------------------------------------------%
% Program for solving Task 2 is AME 521 final project  %
% Anup Kanale, November 2016                          %
%-----------------------------------------------------%

clear all;
close all; clc;

% Is there Impulse?
impulse = 0; % 0- no, 1- yes
I0 = 1200;

%% Define some parameters
%--------------------------
a=4.5;
M = 2.5e3;
I = 3.2e2;
rho = 800;
EI = 7e8;
L = 400;
v0 = 18;
N = 12000;
tTot = (L-a)/v0;
dt=(L-a)/(N*v0);
time = 0:dt:tTot;

%Intial conditions
y10 = 0.02;
yDot10 = 0.6;
y20 = 0.05;
yDot20 = -0.3;
z(:,1) =[0; 0; 0; y10; y20; 0; 0; 0; yDot10; yDot20] ;

%% Mass Matrix
%----------------
syms xx
n = 3; % number of terms of admissible function
for ii=1:n
    phidum(ii) = 1-cos(2*ii*pi*xx/L);
end;
Mb = zeros(n);
Kb = zeros(n);
for ii=1:n
    for jj=1:n
        Mb(ii,jj) = int(rho*phidum(ii)*phidum(jj), 0, L);
        Kb(ii,jj) = int(EI*diff(phidum(ii),2)*diff(phidum(jj),2),0,L);
    end;
end;

% Mass matrix
mMat = zeros(n+2);
mMat(1:n, 1:n) = Mb;
mMat(n+1,n+1) = M/4+I/a^2;
mMat(n+1,n+2) = M/4-I/a^2;
mMat(n+2,n+2) = M/4+I/a^2;
mMat(n+2,n+1) = M/4-I/a^2;

%% Solution using Runge-Kutta 4th Order
%-------------------------------------------
for kk=1:N
    [A1,kMat] = getA(time(kk), mMat, Kb);
    [A2,kMat] = getA(time(kk)+dt/2, mMat, Kb);
    [A3,kMat] = getA(time(kk)+dt, mMat,Kb);
    dMat = zeros(10,1);
    if kk==N/2
        if impulse==1
            b = [0 0 0 0 I0];
            dMat = [zeros(5,1); -inv(mMat)*b']
        end;
    end;
    f1 = A1* z(:,kk);
    f2 = A2* ( z(:,kk) + dt/2*f1 );
    f3 = A2* ( z(:,kk) + dt/2*f2 );
    f4 = A3* ( z(:,kk) + dt*f3 );
    
    z(:,kk+1) = z(:,kk) + dt/6*(f1+2*f2+2*f3+f4) + dMat;
    
end;

figure()
plot(time,z(4,:),'b');
title('Vibration response at the rear end of the car');
xlabel('time', 'FontSize', 12); ylabel('y_1', 'FontSize', 12);

figure()
plot(time,z(5,:),'r');
title('Vibration response at the front end of the car');
xlabel('time', 'FontSize', 12); ylabel('y_2', 'FontSize', 12);

xBeam = linspace(0,L,N);
plotTimeIndex = [1, N/6, 2*N/6, 3*N/6, 4*N/6, 5*N/6, N];
phiMat = zeros(1,3); beamDisp = zeros(N);
for kk=1:7
    for xi=1:length(xBeam)
        phiMat = [1-cos(2*pi*xBeam(xi)/L), 1-cos(2*pi*2*xBeam(xi)/L), 1-cos(2*pi*3*xBeam(xi)/L)];
        beamDisp(kk,xi) = phiMat*z(1:3,plotTimeIndex(kk));
    end;
    plot(xBeam,beamDisp(kk,:), 'LineWidth', 1.5)
    hold on;
end;
legend('t=0', 't=3.66', 't=7.32', 't=10.98', 't=14.64', 't=18.30', 't=21.97','location','best');
xlabel('x', 'FontSize', 12); ylabel('w', 'FontSize', 12);