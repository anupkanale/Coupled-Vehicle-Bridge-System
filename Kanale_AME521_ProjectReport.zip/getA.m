function [A, kMat, cMat, phiMatvt, phiMatvtpa] = getA(tim, mMat, Kb)
%% Define parameters and constants
%---------------------------------------
% Car parameters
a = 4.5;
k1 = 5e5;
k2 = 5e5;
c1 = 3.6e3;
c2 = 3.6e3;
v0 = 18;

% Bridge parameters
L = 400;

%% Initialise Matrices
%-----------------------
phi1vt = 1-cos(2*1*pi*v0*tim/L);
phi2vt = 1-cos(2*2*pi*v0*tim/L);
phi3vt = 1-cos(2*3*pi*v0*tim/L);

phi1vtpa = 1-cos(2*1*pi*(v0*tim+a)/L);
phi2vtpa = 1-cos(2*2*pi*(v0*tim+a)/L);
phi3vtpa = 1-cos(2*3*pi*(v0*tim+a)/L);

phiMatvt = [phi1vt, phi2vt, phi3vt];
phiMatvtpa = [phi1vtpa, phi2vtpa, phi3vtpa];

n=3; % Number of terms in admissible function
kMat = zeros(n+2);
cMat = zeros(n+2);

% Stiffness Matrix
kMat(1:n,1:n) = Kb + k1*(phiMatvt'*phiMatvt) + k2*(phiMatvtpa'*phiMatvtpa);
kMat(1:3,n+1) = -k1*phiMatvt';
kMat(1:3,n+2) = -k2*phiMatvtpa';
kMat(n+1,1:3) = -k1*phiMatvt;
kMat(n+2,1:3) = -k2*phiMatvtpa;
kMat(n+1,n+1) = k1;
kMat(n+2,n+2) = k2;

% Damping Matrix
cMat(1:n,1:n) = c1*(phiMatvt'*phiMatvt) + c2*(phiMatvtpa'*phiMatvtpa);
cMat(1:3,n+1) = -c1*phiMatvt';
cMat(1:3,n+2) = -c2*phiMatvtpa';
cMat(n+1,1:3) = -c1*phiMatvt;
cMat(n+2,1:3) = -c2*phiMatvtpa;
cMat(n+1,n+1) = c1;
cMat(n+2,n+2) = c2;

A = [zeros(n+2), eye(n+2);...
    -inv(mMat)*kMat, -inv(mMat)*cMat];